<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
		<input type="text" placeholder="<?php _e('Search and hit enter...', 'solopine'); ?>" name="s" id="s" />
</form>